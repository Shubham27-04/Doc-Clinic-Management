<!-- doctor_update.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Doctor Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Update Your Details</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="doctorName" class="form-label">Name</label>
            <input type="text" class="form-control" id="doctorName" name="username" required>
        </div>
        <div class="mb-3">
            <label for="doctorPhoto" class="form-label">Upload Photo</label>
            <input type="file" class="form-control" id="doctorPhoto" name="file"  required>
        </div>
        <button type="submit" name="sbt" class="btn btn-primary">Update Details</button>
    </form>
</div>
</body>
</html>



<?php

include "connection.php";

session_start();
$id = $_SESSION['docInfo']['id'];

if(isset($_POST['sbt']))
{
$name =$_POST['username'];
$file_name="image/".$_FILES['file']['name'];

if(move_uploaded_file($_FILES['file']['tmp_name'],$file_name)){
    $sql= "update doctor set name = '$name', image = '$file_name' where id = '$id'";
    $result =mysqli_query($conn,$sql);
    if (mysqli_query($conn, $sql)) {
        echo "Doctor details updated successfully.";
    }
}
}
?>