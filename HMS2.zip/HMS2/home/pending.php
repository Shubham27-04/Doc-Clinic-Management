<?php
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
    include 'connection.php';
    $sql = "SELECT id, name, email, date, time, status FROM patient WHERE status = 'Pending'";
    $result = mysqli_query($conn, $sql);
?>
<table class='table' id="appointment_table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Date</th>
            <th>Time</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
<?php
    while($row = mysqli_fetch_assoc($result))
    {
?>
        <tr>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['time']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td>
            <?php if ($row['status'] == 'Pending') { ?>
                <form method="POST">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <button type="submit" name="approve" class='fa fa-check' style='background-color:green'></button>
                    <button type="submit" name="reject" class='fa fa-remove' style='background-color:red'></button>
                </form>
                <?php } ?>
            </td>
        </tr>
<?php
    }
?>
    </tbody>
</table>

<?php
if (isset($_POST['approve'])) {
    $id = $_POST['id'];
    $sql1 = "UPDATE patient SET status = 'Approved' WHERE id = '$id'";
    mysqli_query($conn, $sql1);
    echo "<script>alert('Appointment approved successfully.'); window.location.href = 'pending.php';</script>";
}
elseif (isset($_POST['reject'])) {
    $id = $_POST['id'];
    $sql2 = "UPDATE patient SET status = 'Rejected' WHERE id = '$id'";
    mysqli_query($conn, $sql2);
    echo "<script>alert('Appointment rejected successfully.');  window.location.href = 'pending.php';</script>";
}
?>

<script>
    new DataTable('#appointment_table');
</script>
</body>
</html>
