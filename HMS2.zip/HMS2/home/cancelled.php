<?php
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
    include 'connection.php';
    $sql = "SELECT id, name, email, date, time, status FROM patient WHERE status = 'Rejected'";
    $result = mysqli_query($conn, $sql);
?>
<table class='table' id="appointment_table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Date</th>
            <th>Time</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
<?php
    while($row = mysqli_fetch_assoc($result))
    {
?>
        <tr>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['time']; ?></td>
            <td><?php echo $row['status']; ?></td>
        </tr>
<?php
    }
?>
    </tbody>
</table>

<script>
    new DataTable('#appointment_table');
</script>
</body>
</html>
