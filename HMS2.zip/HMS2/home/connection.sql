create DATABASE hms;
use hms;

create table patient(name VARCHAR(20),email VARCHAR(30),phone BIGINT,date DATE, time TIME, specialization VARCHAR(30),doctor VARCHAR(20),msg VARCHAR(200));
TRUNCATE patient;

create table doctor(name VARCHAR(20),email VARCHAR(30),specialization VARCHAR(30),password VARCHAR(20));

alter table doctor drop column specialization;
alter table patient drop column specialization;

alter table doctor
modify column image VARCHAR();

desc doctor;
alter table doctor
 modify column id INT PRIMARY KEY AUTO_INCREMENT;

TRUNCATE doctor;
alter table doctor add column id int PRIMARY key NOT NULL AUTO_INCREMENT;


alter table patient add column appointNo int;

alter table doctor
modify column email VARCHAR(50) UNIQUE NOT NULL;

ALTER Table doctor drop column id;

desc doctor;

alter table patient add column status VARCHAR(25) DEFAULT "Pending";

TRUNCATE patient;