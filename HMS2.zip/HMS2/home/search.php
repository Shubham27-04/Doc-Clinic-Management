<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      button#sbt{
        margin-right: 50px;
        border: 1px solid white;
        color: white;
      }
      input#search{
        margin-right: 20px;
        width: 100%;
      }
      form.form-inline{
        display: flex;
      }
    </style>
</head>
<body>
<nav class="navbar navbar-dark bg-primary">
  <h3>search your appointment status</h3>
  <form class="form-inline">
    <input class="form-control mr-sm-2" id="search" type="search" placeholder="search your appointment status" aria-label="Search">
    <button class="btn btn-outline-success my-2 my-sm-0" id="sbt" type="submit">Search</button>
  </form>
</nav>
    <div id="output"></div>


  <script>
$(document).ready(function(){
    $('#sbt').click(function(){
            let appointNo = $('#search').val();
            event.preventDefault();
        $.ajax({
            url:"search_data.php",
            type:"POST",
            data:{appointNo:appointNo},
            success:function(result){
                $('#output').html(result);
        }    
        });
    });

});

  </script>
</body>
</html>



