<?php
include 'connection.php';

$appointNo = $_REQUEST['appointNo'];
if($appointNo != null) {
    $sql = "
    SELECT patient.name, patient.email, patient.phone, patient.date, patient.time, 
           doctor.name as doctor_name, patient.msg, patient.status 
    FROM patient 
    INNER JOIN doctor ON patient.doctor = doctor.id 
    WHERE appointNo = '$appointNo'";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $output = "
        <table class='table table-striped'>
            <thead>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Date</th>
                <th>Time</th>
                <th>Doctor</th>
                <th>Message</th>
                <th>Status</th>
            </thead>
            <tbody>
                <tr>
                    <td>{$row['name']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['phone']}</td>
                    <td>{$row['date']}</td>
                    <td>{$row['time']}</td>
                    <td>{$row['doctor_name']}</td>
                    <td>{$row['msg']}</td>
                    <td>{$row['status']}</td>
                </tr>
            </tbody>
        </table>
        ";
        echo $output;
    } else {
        echo "<script>alert('Appointment number not found. Please check and try again.');</script>";
    }
}
?>
