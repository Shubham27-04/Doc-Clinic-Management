<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Registration</title>
    <link rel="stylesheet" href="doc_reg.css">
</head>

<body>
    <!-- Registration Form -->
    <form class="registration-form" action="" method="POST" enctype="multipart/form-data">
        <h2>Doctor Registration</h2>
        <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="file">Upload your photo:</label>
            <input type="file" id="file" name="file" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="form-group">
            <label for="confirm-password">Confirm Password:</label>
            <input type="password" id="confirm-password" name="confirm_password" required>
        </div>
        <button type="submit" name="sbt" class="btn">Register</button>
        <h4>Already have account? <a href="doc_log.php">login</a></h4>
    </form>

</body>

</html>


<?php

include "connection.php";

if(isset($_POST['sbt']))
{
$name =$_POST['username'];
$email =$_POST['email'];
$password =$_POST['password'];
$confirm_password =$_POST['confirm_password'];
$file_name="image/".$_FILES['file']['name'];
// $temp_name=$_FILES['file']['temp_name'];
// $folder="image/".$file_name;

$sql_e = "SELECT * FROM doctor WHERE email='$email'";
$res_e = mysqli_query($conn, $sql_e);

if(mysqli_num_rows($res_e) > 0)
        {
            echo "<script>alert('Sorry... email already taken')</script>";
        }
elseif($password!=$confirm_password)
        {
            echo "<script>alert('password does not match')</script>";
        }
elseif(move_uploaded_file($_FILES['file']['tmp_name'],$file_name)){
$sql= "insert into doctor(name,email,password,image)values('$name','$email','$password','$file_name')";
$result =mysqli_query($conn,$sql);
if($result){
    echo "<script>
  alert('Registered succesfully');
  window.location.href = 'doc_log.php';
  </script>
  ";
    header('location:doc_log.php');
            }
    }
}

?>