<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Registration</title>
    <link rel="stylesheet" href="doc_log.css">
</head>
<body>
    <!-- Registration Form -->
    <form class="login-form" action="" method="POST">
        <h2>Doctor Registration</h2>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" name="sbt" class="btn">Login</button>
        <h4>Don't have account?<a href="doc_reg.php">Signup</a></h4>
    </form>
    
</body>
</html>

<?php
include "connection.php";

if(isset($_POST['sbt']))
{
    $email=$_POST['email'];
    $password=$_POST['password'];

    $sql= "select name,email,id,image from doctor where email='$email' and password='$password'";
    $result = mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        session_start();
        $_SESSION['docInfo']=mysqli_fetch_assoc($result);
        header('location:doc_dash.php');
    }
    else{
        echo "<script>alert('email or password does not match')</script>";
    }
}

?>
