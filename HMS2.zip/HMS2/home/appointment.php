<?php
    include 'connection.php';
        $appointNo = rand(111111,999999);
        $name = $_POST['fullName'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $date = $_POST['date'];
        $time = $_POST['time'];
        $doctor =  $_POST['doctor'];
        $msg =  $_POST['message'];
    $sql= "insert into patient(appointNo,name,email,phone,date,time,doctor,msg)values('$appointNo','$name','$email','$phone','$date','$time','$doctor','$msg')";
    $result = mysqli_query($conn,$sql);
    if($result)
    {
        $cmd = "select appointNo from patient where appointNo = '$appointNo' ORDER BY time DESC LIMIT 1";
        $res = mysqli_query($conn,$cmd);
        $row = mysqli_fetch_assoc($res);
        echo "<script>
            alert('thanks for submitting Your appointment id is $row[appointNo]');
            window.location.href='home.php';
            </script>";
    }
    else{
    echo "<script>alert('something wrong');</script>";
    }