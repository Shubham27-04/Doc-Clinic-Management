<?php
$sql = "select * from patient";
            $result = mysqli_query($conn,$sql);