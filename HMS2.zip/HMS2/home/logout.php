<?php
session_start();
session_unset();

session_destroy();
// echo 'You have been logged out. <a href="doc_log.php" target= "blank">Go back</a>';
echo "
<script>

alert('You have been logged out')
window.location.href = 'doc_log.php';

</script>
";

?>