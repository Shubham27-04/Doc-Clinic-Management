<!DOCTYPE html>
<html lang="en">

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Management System</title>
    <link rel="stylesheet" href="home.css">
</head>

<body>
    <!-- Navigation Bar -->
    <nav>
        <div class="logo">Hospital Management</div>
        <ul>
            <li><a href="doc_reg.php" class="btn btn-outline-danger">Doctor</a></li>
            <li><a href="search.php" class="btn btn-outline-danger">Search your appointment</a></li>
        </ul>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Welcome to Our Hospital Management System</h1>
            <p>Efficiently manage appointments, patient records, and hospital administration all in one place.</p>
        </div>
    </section>

    <!-- Info Section -->
    <section class="info">
        <h2>About Our System</h2>
        <p>Our hospital management system is designed to streamline operations for doctors, patients, and
            administrators, providing a seamless experience for all users.</p>
    </section>
    <!-- Appointment Booking Section -->
    <section class="appointment-form">
        <h2>Book an Appointment</h2>
        <form action="appointment.php" method="POST">
            <div class="form-group">
                <label for="fullName">Full Name:</label>
                <input type="text" id="fullName" name="fullName" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number:</label>
                <input type="tel" id="phone" name="phone" required>
            </div>

            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" min="<?php echo date('Y-m-d'); ?>" required>
            </div>

            <div class="form-group">
                <label for="time">Time:</label>
                <input type="time" id="time" name="time" required>
            </div>

                    <?php
                    
            include 'connection.php';

            $sql = "select * from doctor";
            $result = mysqli_query($conn,$sql);
            $row=mysqli_fetch_assoc($result);
                
            
               
?>

            <div class="form-group">
                <label for="doctor">Select Doctor:</label>
                <select id="doctor" name="doctor" required>
                    <option value="">Select Doctor</option>
                    <?php
                        foreach($result as $row)
                        {
                        ?>
                    <option value="<?php echo $row['id']?>"><?php echo $row['name']?></option>
                   <?php 
                        }
                   ?>
                    <!-- Add more doctors here -->
                </select>
            </div>

            

            <div class="form-group">
                <label for="message">Additional Message:</label>
                <textarea id="message" name="message" rows="4"></textarea>
            </div>

            <button type="submit" class="btn btn-primary" id="sbt">Book Appointment</button>
        </form>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Hospital Management System. All Rights Reserved.</p>
    </footer>
</body>

</html>