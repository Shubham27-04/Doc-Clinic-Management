<?php
session_start();
if(!isset($_SESSION['docInfo'])){
    header('location:doc_log.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Appointment Dashboard</title>
        <link rel="stylesheet" href="doc_dash.css" >
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="user-profile">
            <?php include 'connection.php';
                // session_start();
                $email = $_SESSION['docInfo']['email'];
                $sql = "select * from doctor where email = '$email'";
                $result = mysqli_query($conn,$sql);
                    while($row=mysqli_fetch_assoc($result)>0)
                    {
                    foreach($result as $row)
                {
            ?>
                <img src="<?php echo $row['image']?> " alt="User Profile">
                <p><?php
                echo $_SESSION['docInfo']['name']; ?></p>
            </div>
            <?php
                }
            }
                ?>
            <ul>
                <li><a href="doc_dash.php">Dashboard</a></li>
                <li><a href="pending.php">Pending Appointments</a></li>
                <li><a href="patient_list.php">Patients</a></li>
                <li><a href="doc_update.php">Settings</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>

<!-- ---------------------------------Todays Appointments------------------------------------- -->
<?php              
        include 'connection.php';
        $sql1 ="SELECT *
        FROM patient WHERE DATE(date) = CURDATE()";
        $result1 = mysqli_query($conn,$sql1);
        $count1 = mysqli_num_rows($result1);
?>
        <div class="content">
            <div class="dashboard">
                <h2>Doctor Appointment Management System</h2>
                <div class="card">
                    <div class="info">
                        <h3>Todays Appointment</h3>
                        <p><?php echo $count1; ?></p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-plus-circle"></i>
                    </div>
                    <button class="action"><a style = "text-decoration:none; color:white" href="today_appoint.php">View Detail</a></button>
                </div>


 <!-- ----------------------------------cancelled Appointments------------------------------------ -->
            
<?php
        $sql2 ="select * from patient where status = 'Rejected'";
        $result2 = mysqli_query($conn,$sql2);
        $count2 = mysqli_num_rows($result2);
?>
                <div class="card cancelled">
                    <div class="info">
                        <h3>Cancelled Appointment</h3>
                        <p><?php echo $count2; ?></p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-ban"></i>
                    </div>
                    <button class="action"><a style = "text-decoration:none; color:white" href="cancelled.php">View Detail</a></button>
                </div>


<!-- ------------------------------------Approved Appointments------------------------------------------ -->

<?php
        $sql3 ="select * from patient where status = 'Rejected'";
        $result3 = mysqli_query($conn,$sql3);
        $count3 = mysqli_num_rows($result3);
?>

                <div class="card approved">
                    <div class="info">
                        <h3>Total Approved</h3>
                        <p><?php echo $count3 ; ?></p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <button class="action"><a style = "text-decoration:none; color:white" href="approved.php">View Detail</a></button>
                </div>

                <?php              
                    include 'connection.php';
                     $sql = "select * from patient";
                    $result = mysqli_query($conn,$sql);
                    $count = mysqli_num_rows($result);
                ?>
                <div class="card total">
                    <div class="info">
                        <h3>Total Appointment</h3>
                        <p><?php echo $count; ?></p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <button class="action"><a style = "text-decoration:none; color:white" href="patient_list.php">View Detail</a></button>
                </div>
            </div>
        </div>
    </div>
    <script src="https://kit.fontawesome.com/your-font-awesome-kit-id.js" crossorigin="anonymous"></script>
</body>
</html>